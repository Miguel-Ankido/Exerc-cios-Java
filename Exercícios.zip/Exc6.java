public class Exc6 { 

    public static void main(String[] args) {
        //(20 - 15)/2
       //  2 ˆ (5/20) + 30 / (15 ˆ 2)
        // 35 / (6 + 2)
       // 23 módulo 4
         double resultado1 = ((20 - 15)/2.0);
         System.out.println("O resultado da primeira equação é: " + resultado1);

         double resultado2 = ((5/20) * (5/20) + 30 / (15*15));
        System.out.println("O resultado da segunda equação é: "+ resultado2);
        
        double resultado3 = (35 / (6 + 2));
        System.out.println("O resultado da segunda equação é: "+ resultado3);

        double resultado4 = (23%4);
        System.out.println("O resultado da segunda equação é: "+ resultado4);
       
        
        
       
        
       

    }
    

}