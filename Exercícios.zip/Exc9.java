public class Exc9 {
    
    public static void main(String[] args) {
//A fórmula para calcular a área de um quadrado é A = L x L, ou seja, A = L². 
// A = área; L = Lado
// Calcule área de 350 metros lado
        double lado = 350;
        double area = (lado*lado);
        
        System.out.println("A área do quadrado é: " + area + " Metros");
 
    }

}
