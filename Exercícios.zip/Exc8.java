public class Exc8 {
    public static void main(String[] args) {
     //8.0, 7.5, 4.5 e 9
        double nota1 = 8.0;
        double nota2 = 7.5;
        double nota3 = 4.5;
        double nota4 = 9.0;
        System.out.println("As suas notas foram: "+ nota1);
        System.out.println(nota2);
        System.out.println(nota3);
        System.out.println(nota4);
        // agora calcule a média 
        double media = ((nota1 + nota2 + nota3 + nota4)/4);
        System.out.println("E sua média é de: "+ media);

    }

}
