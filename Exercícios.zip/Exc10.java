public class Exc10 {
    //o cálculo da área de um círculo com raio de 5 cm. (π = 3.14159)
// área do círculo = π ˆ r2
//A = π r². 
public static void main(String[] args) {
    double raio = 5;
    double pi = 3.14159;
    double area = pi*(raio*raio);
    System.out.println("A área de um círculo com raio de 5 é de: " + area + " cm");


    }
}
